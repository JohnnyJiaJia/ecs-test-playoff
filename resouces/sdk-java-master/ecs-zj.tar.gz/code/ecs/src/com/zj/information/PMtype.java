package com.zj.information;

public enum PMtype {
	General("General"),Large_Memory("Large-Memory"),High_Performance("High-Performance");

	private String _name;

	private PMtype(String _name) {
		this._name = _name;
	}



}
