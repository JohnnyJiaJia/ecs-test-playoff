package com.zj.utils;

public class Util {

	public final static int CPU = 1;
	public final static int MEM = 2;
	public final static int RATE = 3;
	public final static int RAM = 4;

	public final static String General = "General";
	public final static String Large_Memory = "Large-Memory";
	public final static String High_Performance = "High-Performance";


}

